<?php
error_reporting(E_ALL); 
ini_set('display_errors', TRUE); 
ini_set('display_startup_errors', TRUE);

include('classes/db.class.php');
$db = new db('host', 'user', 'pass', 'name');

include('classes/user.class.php');
$user = new user(0, 'Dmitry', 'Terentiev', '20.03.2000', 0, 'Minsk');
echo $user->getUserData(1);