<?php

class db
{
	public $db_id;
	public $query_id;
	
	public $error;
	
	public function __construct($h, $u, $p, $n)
	{
		if(!$this->connect($h, $u, $p, $n))
		{
			return false;
		}
		
		return $this->db_id;
	}
	
	public function connect($h, $u, $p, $n)
	{
		if(@!$this->db_id = mysqli_connect($h, $u, $p, $n))
		{
			$this->error = 'Невозможно установить соединение с базой данных';
			return false;
		}
		
		return true;
	}
	
	public function query($query, $db_id = false)
	{
		if(!$db_id) $db_id = $this->db_id;
		
		if(@!$this->query_id = mysqli_query($db_id, $query))
		{
			$this->error = 'Невозможно выполнить SQL запрос';
			return false;
		}
		
		if(is_resource($this->query_id))
		{
			$i = 0;
			$data = [];
			
			while($row = $this->row($this->query_id))
			{
				$data[$i] = $row;
				$i++;
			}
			
			return $data;
		}else{
			return $this->query_id;
		}
	}
	
	public function row($query)
	{
		return mysqli_fetch_assoc($query);
	}
	public function num($query)
	{
		return mysqli_num_rows($query);
	}
	
	public function clear($data)
	{
		return mysqli_real_escape_string($this->db_id, $data);
	}
	
	public function id($db_id = false)
	{
		if(!$db_id) $db_id = $this->db_id;
		return mysqli_insert_id($db_id);
	}
	
	public function close($db_id)
	{
		return mysqli_close($db_id);
	}
}
?>