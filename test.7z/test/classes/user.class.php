<?php

class user
{
	public $db;
	public $id;
	public $first_name;
	public $last_name;
	public $dob;
	public $sex;
	public $city;
	
	public function __construct($id, $first_name, $last_name, $dob, $sex, $city)
	{
		global $db;
		
		$this->db = $db;
		$this->id = $id;
		$this->first_name = $first_name;
		$this->last_name = $last_name;
		$this->dob = $dob;
		$this->sex = $sex;
		$this->city = $city;
		
		$this->AddUser();
	}
	
	public function AddUser()
	{
		$sql = "INSERT INTO `users` SET";
		$sql .= " `user_id` = '".$this->id."',";
		$sql .= " `first_name` = '".$this->first_name."',";
		$sql .= " `last_name` = '".$this->last_name."',";
		$sql .= " `dob` = '".$this->dob."',";
		$sql .= " `sex` = '".$this->sex."',";
		$sql .= " `city` = '".$this->city."'";
		
		$this->db->query($sql);
	}
	
	public function DelUser()
	{
		$sql = "DELETE FROM users WHERE `user_id` = $this->id";
		$this->db->query($sql);
	}

	public function getUserData($method)
	{
		$obj_user = new stdClass;
		$obj_user->id = $this->id;
		$obj_user->first_name = $this->first_name;
		$obj_user->last_name = $this->last_name;
		$obj_user->dob = $this->dob;
		$obj_user->sex = $this->sex;
		$obj_user->city = $this->city;
		
		switch($method)
		{
			case 0:
				$obj_user->age = $this->getAge($this->dob);
				break;
			case 1:
				$obj_user->toSex = $this->toStringSex($this->sex);
				break;
		}

		return var_dump($obj_user);
	}
	
	public static function toStringSex($num) 
	{
		switch($num)
		{
			case 0:
				$sex = 'муж';
				break;
			case 1:
				$sex = 'жен';
				break;
		}
		
		return $sex;
	}
	
	public static function getAge($date) 
	{
		return intval(date('Y', time() - strtotime($date))) - 1970;
	}
}

?>